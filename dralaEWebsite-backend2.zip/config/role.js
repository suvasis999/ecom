module.exports = {
    ADMIN:"admin",
    VENDOR:"vendor",
    BASIC: "basic",
}
module.exports = {
    mongoURI:"mongodb+srv://satyam:satyam@cluster0.ziri6.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    secretOrKey: "secret",
  };
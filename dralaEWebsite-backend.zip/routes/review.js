const Review = require('../controller/review')
const express = require('express');
const router = express.Router();


router.post('/add',Review.addReview);

module.exports = router;  

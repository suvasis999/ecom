const Review = require("../models/review")
const Product = require("../models/Product")
const Vendor = require("../models/vendor")
const mongoose = require("mongoose")
const vendorOverAllReview = async(vendor_id)=>{
    if(!vendor_id)return null
    const allReview = await Product.aggregate([
        {
            $match:{
                vendor_id:mongoose.Types.ObjectId(vendor_id)
            },

        },
        {
            $group:
              {
                _id: "null",
                avgRating: { $avg: "$rating" },
                totalRating: { 
                    $sum: "$rateCount" 
                } 
              }
          }
    ])
    const avgRatings = Number.parseFloat((100 * allReview[0].avgRating) / 5).toFixed(2);
    await Vendor.findByIdAndUpdate(vendor_id,{
        average_rating:avgRatings ,
        total_rating:allReview[0].totalRating
    })
}
module.exports.addReview = async (req, res, next) => {
    try {
        const { description, rating, product_id, vendor_id, user_id } = req.body;

        const ratedBefore = await Review.countDocuments({ user_id: user_id, product_id: product_id })
        if (ratedBefore) {
            return res.status(400).send({ status: false, msg: "Already reviewed" });
        }
        const NewReview = await Review.create({ description, rating, product_id, vendor_id, user_id });
        await Product.updateOne({ _id: product_id },
            {
                $inc: { 'rateCount': 1, 'rateValue': rating },
            }
        )
        await Product.updateOne({ _id: product_id },
            [{ $set: { "rating": { $round: [{ $divide: ["$rateValue", "$rateCount"] }, 1] } } }]
        )
        vendorOverAllReview(vendor_id)
        if (NewReview != null) {
            res.status(200).send({ status: true, data: NewReview, msg: 'Product review has been added' });
        }
        else {
            res.status(200).send({ status: false, msg: 'Product review could not be added' });
        }
    }
    catch (er) {
        next(er)
    }
}



module.exports.editReview = async (req, res, next) => {
    try {
        const { description, rating, review_id,vendor_id } = req.body;
        if (!description || !rating || !review_id) {
            return res.status(400).send({ status: false, msg: "Please fill all the field" });
        }
        const getReview = await Review.findById(review_id)
        if (getReview != null) {
            await Review.findByIdAndUpdate(review_id, { description, rating })
            const updateRating = rating - getReview.rating
            await Product.updateOne({ _id: getReview.product_id },
                {
                    $inc: { 'rateValue': updateRating },
                }
            )
            await Product.updateOne({ _id: getReview.product_id },
                [{ $set: { "rating": { $round: [{ $divide: ["$rateValue", "$rateCount"] }, 1] } } }]
            )
            vendorOverAllReview(vendor_id)
        }
        if (getReview != null) {
            res.status(200).send({ status: true, msg: 'Product review edited' });
        }
        else {
            res.status(200).send({ status: false, msg: 'Product review could not be edited' });
        }
    }
    catch (er) {
        next(er)
    }
}
module.exports.viewReview = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = 30
        const skip = page ? (page - 1) * limit : 0;
        const product_id = req.params.product_id;
        if (!product_id) {
            return res.status(400).send({ status: false, msg: 'Product_id  not found' });
        }
        const viewreview = await Review.aggregate(
            [
                { $match: { product_id: new mongoose.Types.ObjectId(product_id) } },
                { $skip: skip },
                { $limit: limit },
                {
                    $lookup:
                    {
                        from: 'products',
                        let: { productId: "$product_id" },
                        pipeline: [
                            {
                                $match: {
                                    $and: [
                                        {
                                            $expr: {
                                                $eq: ["$$productId", "$_id"]
                                            }
                                        }
                                    ]
                                }
                            },
                        ],
                        as: "product_details",
                    },
                },
            ]
        )
        if (viewreview != null) {
            res.status(200).send({ status: true, data: viewreview, msg: 'Product review details found' });
        }
        else {
            res.status(200).send({ status: false, msg: 'Product review could not be found' });
        }
    }
    catch (er) {
        next(er)
    }
}

module.exports.viewReviewByUser = async (req, res) => {
    try {
        const user_id = req.params.user_id;
        if (!user_id) {
            return res.status(400).send({ status: false, msg: 'user_id  not found' });
        }
        const page = parseInt(req.query.page) || 1;
        const limit = 30
        const skip = page ? (page - 1) * limit : 0;
        // const viewreview = await Review.find({ user_id: user_id }).skip(skip).limit(limit)
        const viewreview = await Review.aggregate(
            [
                { $match: { user_id: new mongoose.Types.ObjectId(user_id) } },
                { $skip: skip },
                { $limit: limit },
                {
                    $lookup:
                    {
                        from: 'products',
                        let: { productId: "$product_id" },
                        pipeline: [
                            {
                                $match: {
                                    $and: [
                                        {
                                            $expr: {
                                                $eq: ["$$productId", "$_id"]
                                            }
                                        }
                                    ]
                                }
                            },
                        ],
                        as: "product_details",
                    },
                },
            ]
        )
        if (viewreview != null) {
            res.status(200).send({ status: true, data: viewreview, msg: 'product review details found' });
        }
        else {
            res.status(200).send({ status: false, msg: 'product review could not be found' });
        }
    }
    catch (er) {
        next(er)
    }
}




module.exports.Reviewlist = async (req, res) => {
    try {

        if (!req.params.product_id) {
            return res.status(400).send({ status: false, msg: 'product_id  not found' });
        }
        const page = parseInt(req.query.page) || 1;
        const limit = 30
        const skip = page ? (page - 1) * limit : 0;
        const productdetailsList = await Review.aggregate(
            [
                { $match: { product_id: new mongoose.Types.ObjectId(req.params.product_id) } },
                { $skip: skip },
                { $limit: limit },

                {
                    $lookup:
                    {
                        from: 'users',
                        let: { userId: "$user_id" },
                        pipeline: [
                            {
                                $match: {
                                    $and: [
                                        {
                                            $expr: {
                                                $eq: ["$$userId", "$_id"]
                                            }
                                        }
                                    ]
                                },
                            },
                            {
                                $project: {
                                    name: 1,
                                    location: 1,
                                    gender: 1
                                }
                            }
                        ],
                        as: "user_details",
                    },
                },
                {
                    $lookup:
                    {
                        from: 'products',
                        let: { productId: "$product_id" },
                        pipeline: [
                            {
                                $match: {
                                    $and: [
                                        {
                                            $expr: {
                                                $eq: ["$$productId", "$_id"]
                                            }
                                        }
                                    ]
                                }
                            },
                        ],
                        as: "product_details",
                    },
                },
            ]
        )
        if (productdetailsList != null) {
            res.status(200).send({ status: true, data: productdetailsList, msg: 'product reviews list' });
        }
        else {
            res.status(200).send({ status: false, msg: 'product review list not found' });
        }
    }
    catch (er) {
        next(er)
    }
}


